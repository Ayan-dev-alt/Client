const express = require("express");
const db = require("../config/database");
const adminAuth = require("../middleware/adminAuth");

const router = express.Router();

/* =========================================================
   GET SETTINGS
   ADMIN ONLY
========================================================= */

router.get("/", adminAuth, (req, res) => {
    db.all(
        "SELECT * FROM settings WHERE id = 1 LIMIT 1",
        [],
        (err, rows) => {
            if (err) {
                console.error("Get settings error:", err);

                return res.status(500).json({
                    success: false,
                    message: "Could not load settings."
                });
            }

            const settings =
                rows && rows.length
                    ? rows[0]
                    : null;

            if (!settings) {
                return res.status(404).json({
                    success: false,
                    message: "Settings not found."
                });
            }

            res.json({
                success: true,
                settings
            });
        }
    );
});


/* =========================================================
   UPDATE SETTINGS
   ADMIN ONLY
========================================================= */

router.put("/", adminAuth, (req, res) => {

    const {
        store_name,
        store_email,
        store_phone,
        currency,
        store_address,
        shipping_charge,
        free_shipping_above,
        store_status,
        cod_enabled,
        registration_enabled,
        notify_orders,
        notify_customers,
        notify_messages,
        notify_low_stock,
        notify_email,
        admin_name,
        admin_email,
        admin_phone,
        two_factor
    } = req.body;


    const storeName =
        String(
            store_name ||
            "New Brand Fashion"
        ).trim();


    const storeEmail =
        String(
            store_email ||
            ""
        ).trim();


    const storePhone =
        String(
            store_phone ||
            ""
        ).trim();


    const storeCurrency =
        String(
            currency ||
            "PKR"
        ).trim();


    const storeAddress =
        String(
            store_address ||
            ""
        ).trim();


    const shippingCharge =
        Number.isFinite(
            Number(shipping_charge)
        )
            ? Number(shipping_charge)
            : 0;


    const freeShippingAbove =
        Number.isFinite(
            Number(free_shipping_above)
        )
            ? Number(free_shipping_above)
            : 0;


    const storeStatus =
        store_status ? 1 : 0;


    const codEnabled =
        cod_enabled ? 1 : 0;


    const registrationEnabled =
        registration_enabled ? 1 : 0;


    const notifyOrders =
        notify_orders ? 1 : 0;


    const notifyCustomers =
        notify_customers ? 1 : 0;


    const notifyMessages =
        notify_messages ? 1 : 0;


    const notifyLowStock =
        notify_low_stock ? 1 : 0;


    const notifyEmail =
        notify_email ? 1 : 0;


    const twoFactor =
        two_factor ? 1 : 0;


    const adminName =
        String(
            admin_name ||
            "Administrator"
        ).trim();


    const adminEmail =
        String(
            admin_email ||
            "admin@newbrandfashion.com"
        ).trim();


    const adminPhone =
        String(
            admin_phone ||
            ""
        ).trim();


    db.run(
        `
        UPDATE settings
        SET
            store_name = ?,
            store_email = ?,
            store_phone = ?,
            currency = ?,
            store_address = ?,
            shipping_charge = ?,
            free_shipping_above = ?,
            store_status = ?,
            cod_enabled = ?,
            registration_enabled = ?,
            notify_orders = ?,
            notify_customers = ?,
            notify_messages = ?,
            notify_low_stock = ?,
            notify_email = ?,
            admin_name = ?,
            admin_email = ?,
            admin_phone = ?,
            two_factor = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = 1
        `,
        [
            storeName,
            storeEmail,
            storePhone,
            storeCurrency,
            storeAddress,
            shippingCharge,
            freeShippingAbove,
            storeStatus,
            codEnabled,
            registrationEnabled,
            notifyOrders,
            notifyCustomers,
            notifyMessages,
            notifyLowStock,
            notifyEmail,
            adminName,
            adminEmail,
            adminPhone,
            twoFactor
        ],
        function (err) {

            if (err) {

                console.error(
                    "Update settings error:",
                    err
                );

                return res.status(500).json({
                    success: false,
                    message:
                        "Settings could not be saved."
                });
            }


            if (this.changes === 0) {

                return res.status(404).json({
                    success: false,
                    message:
                        "Settings record not found."
                });
            }


            db.all(
                "SELECT * FROM settings WHERE id = 1 LIMIT 1",
                [],
                (selectErr, rows) => {

                    if (selectErr) {

                        console.error(
                            "Get updated settings error:",
                            selectErr
                        );

                        return res.json({
                            success: true,
                            message:
                                "Settings saved successfully."
                        });
                    }


                    res.json({
                        success: true,
                        message:
                            "Settings saved successfully.",
                        settings:
                            rows &&
                            rows.length
                                ? rows[0]
                                : null
                    });

                }
            );

        }
    );

});


/* =========================================================
   RESET SETTINGS
   ADMIN ONLY
========================================================= */

router.post(
    "/reset",
    adminAuth,
    (req, res) => {

        db.run(
            `
            UPDATE settings
            SET
                store_name = 'New Brand Fashion',
                store_email = 'info@newbrandfashion.com',
                store_phone = '03XX-XXXXXXX',
                currency = 'PKR',
                store_address = 'Karachi, Sindh, Pakistan',
                shipping_charge = 250,
                free_shipping_above = 5000,
                store_status = 1,
                cod_enabled = 1,
                registration_enabled = 1,
                notify_orders = 1,
                notify_customers = 1,
                notify_messages = 1,
                notify_low_stock = 1,
                notify_email = 0,
                admin_name = 'Administrator',
                admin_email = 'admin@newbrandfashion.com',
                admin_phone = '03XX-XXXXXXX',
                two_factor = 0,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = 1
            `,
            [],
            function (err) {

                if (err) {

                    console.error(
                        "Reset settings error:",
                        err
                    );

                    return res.status(500).json({
                        success: false,
                        message:
                            "Settings could not be reset."
                    });
                }


                if (this.changes === 0) {

                    return res.status(404).json({
                        success: false,
                        message:
                            "Settings record not found."
                    });
                }


                res.json({
                    success: true,
                    message:
                        "Settings reset successfully."
                });

            }
        );

    }
);


module.exports = router;