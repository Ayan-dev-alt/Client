const express = require("express");
const db = require("../config/database");
const adminAuth = require("../middleware/adminAuth");

const router = express.Router();


/*
========================================
CREATE ORDER
PUBLIC ROUTE
POST /api/orders

Customer checkout ke liye public rahega.
========================================
*/

router.post("/", (req, res) => {

    const {
        orderNumber,
        customer,
        note,
        payment,
        paymentMethod,
        transactionId,
        paymentScreenshot,
        paymentProofName,
        items,
        subtotal,
        shipping,
        total,
        advancePayment,
        status
    } = req.body;


    if (
        !customer ||
        !customer.name ||
        !customer.phone ||
        !customer.address ||
        !items ||
        !Array.isArray(items) ||
        items.length === 0
    ) {

        return res.status(400).json({

            success: false,

            message:
                "Customer details and order items are required."

        });

    }


    const finalOrderNumber =
        orderNumber || "NBF-" + Date.now();


    const finalStatus =
        status || "Pending";


    const createdAt =
        new Date().toISOString();


    const customerData =
        JSON.stringify(customer);


    const itemsData =
        JSON.stringify(items);


    db.run(

        `
        INSERT INTO orders
        (
            order_number,
            customer,
            note,
            payment,
            payment_method,
            transaction_id,
            payment_screenshot,
            payment_proof_name,
            items,
            subtotal,
            shipping,
            total,
            advance_payment,
            status,
            created_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,

        [
            finalOrderNumber,
            customerData,
            note || "",
            payment || "",
            paymentMethod || "",
            transactionId || "",
            paymentScreenshot || "",
            paymentProofName || "",
            itemsData,
            Number(subtotal) || 0,
            Number(shipping) || 0,
            Number(total) || 0,
            Number(advancePayment) || 0,
            finalStatus,
            createdAt
        ],

        function (err) {

            if (err) {

                console.error(
                    "Create order error:",
                    err
                );

                return res.status(500).json({

                    success: false,

                    message:
                        "Order could not be saved.",

                    error:
                        err.message

                });

            }


            res.status(201).json({

                success: true,

                message:
                    "Order placed successfully.",

                order: {

                    id:
                        this.lastID,

                    orderNumber:
                        finalOrderNumber,

                    status:
                        finalStatus,

                    createdAt:
                        createdAt

                }

            });

        }

    );

});


/*
========================================
GET ALL ORDERS
ADMIN ONLY
GET /api/orders
========================================
*/

router.get("/", adminAuth, (req, res) => {

    db.all(

        `
        SELECT *
        FROM orders
        ORDER BY id DESC
        `,

        [],

        (err, orders) => {

            if (err) {

                console.error(
                    "Get orders error:",
                    err
                );

                return res.status(500).json({

                    success: false,

                    message:
                        "Could not load orders.",

                    error:
                        err.message

                });

            }


            const formattedOrders =
                orders.map(order => {

                    let customer = {};
                    let items = [];


                    try {

                        customer =
                            JSON.parse(
                                order.customer || "{}"
                            );

                    } catch (e) {

                        customer = {};

                    }


                    try {

                        items =
                            JSON.parse(
                                order.items || "[]"
                            );

                    } catch (e) {

                        items = [];

                    }


                    return {

                        ...order,

                        customer:
                            customer,

                        items:
                            items

                    };

                });


            res.json({

                success: true,

                orders:
                    formattedOrders

            });

        }

    );

});


/*
========================================
GET SINGLE ORDER
ADMIN ONLY
GET /api/orders/:id

Supports BOTH:

1. Database ID
   /api/orders/1

2. Order Number
   /api/orders/NBF-98322785
========================================
*/

router.get("/:id", adminAuth, (req, res) => {

    const orderId =
        req.params.id;


    const isNumericId =
        /^\d+$/.test(orderId);


    const query =
        isNumericId

            ? `
                SELECT *
                FROM orders
                WHERE id = ?
              `

            : `
                SELECT *
                FROM orders
                WHERE order_number = ?
              `;


    db.all(

        query,

        [orderId],

        (err, orders) => {

            if (err) {

                console.error(
                    "Get order error:",
                    err
                );

                return res.status(500).json({

                    success: false,

                    message:
                        "Could not load order.",

                    error:
                        err.message

                });

            }


            if (
                !orders ||
                orders.length === 0
            ) {

                return res.status(404).json({

                    success: false,

                    message:
                        "Order not found."

                });

            }


            const order =
                orders[0];


            try {

                order.customer =
                    JSON.parse(
                        order.customer || "{}"
                    );

            } catch (e) {

                order.customer = {};

            }


            try {

                order.items =
                    JSON.parse(
                        order.items || "[]"
                    );

            } catch (e) {

                order.items = [];

            }


            res.json({

                success: true,

                order:
                    order

            });

        }

    );

});


/*
========================================
UPDATE ORDER STATUS
ADMIN ONLY
PUT /api/orders/:id/status

Supports BOTH:

1. Database ID
2. Order Number
========================================
*/

router.put(
    "/:id/status",
    adminAuth,
    (req, res) => {

        const orderId =
            req.params.id;


        const {
            status
        } = req.body;


        if (!status) {

            return res.status(400).json({

                success: false,

                message:
                    "Order status is required."

            });

        }


        const isNumericId =
            /^\d+$/.test(orderId);


        const query =
            isNumericId

                ? `
                    UPDATE orders
                    SET status = ?
                    WHERE id = ?
                  `

                : `
                    UPDATE orders
                    SET status = ?
                    WHERE order_number = ?
                  `;


        db.run(

            query,

            [
                status,
                orderId
            ],

            function (err) {

                if (err) {

                    console.error(
                        "Update order status error:",
                        err
                    );

                    return res.status(500).json({

                        success: false,

                        message:
                            "Order status could not be updated.",

                        error:
                            err.message

                    });

                }


                if (this.changes === 0) {

                    return res.status(404).json({

                        success: false,

                        message:
                            "Order not found."

                    });

                }


                res.json({

                    success: true,

                    message:
                        "Order status updated successfully."

                });

            }

        );

    }
);


/*
========================================
DELETE ORDER
ADMIN ONLY
DELETE /api/orders/:id

Supports BOTH:

1. Database ID
2. Order Number
========================================
*/

router.delete(
    "/:id",
    adminAuth,
    (req, res) => {

        const orderId =
            req.params.id;


        const isNumericId =
            /^\d+$/.test(orderId);


        const query =
            isNumericId

                ? `
                    DELETE FROM orders
                    WHERE id = ?
                  `

                : `
                    DELETE FROM orders
                    WHERE order_number = ?
                  `;


        db.run(

            query,

            [orderId],

            function (err) {

                if (err) {

                    console.error(
                        "Delete order error:",
                        err
                    );

                    return res.status(500).json({

                        success: false,

                        message:
                            "Order could not be deleted.",

                        error:
                            err.message

                    });

                }


                if (this.changes === 0) {

                    return res.status(404).json({

                        success: false,

                        message:
                            "Order not found."

                    });

                }


                res.json({

                    success: true,

                    message:
                        "Order deleted successfully."

                });

            }

        );

    }
);


module.exports = router;