const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const db = require("./config/database");

const authRoutes = require("./routes/auth");
const productsRoutes = require("./routes/products");
const ordersRoutes = require("./routes/orders");
const settingsRoutes = require("./routes/settings");
const messagesRoutes = require("./routes/messages");

dotenv.config();

const app = express();

const PORT =
    process.env.PORT || 5000;


// ================================
// MIDDLEWARE
// ================================

app.use(cors());

app.use(
    express.json({
        limit: "20mb"
    })
);

app.use(
    express.urlencoded({
        extended: true,
        limit: "20mb"
    })
);


// ================================
// HOME / SERVER TEST
// ================================

app.get("/", (req, res) => {

    res.json({

        success: true,

        message:
            "New Brand Fashion Backend is running!"

    });

});


// ================================
// AUTH ROUTES
// ================================

app.use(
    "/api/auth",
    authRoutes
);


// ================================
// PRODUCT ROUTES
// ================================

app.use(
    "/api/products",
    productsRoutes
);


// ================================
// ORDER ROUTES
// ================================

app.use(
    "/api/orders",
    ordersRoutes
);


// ================================
// SETTINGS ROUTES
// ================================

app.use(
    "/api/settings",
    settingsRoutes
);


// ================================
// MESSAGE ROUTES
// ================================

app.use(
    "/api/messages",
    messagesRoutes
);


// ================================
// 404 API ROUTE
// ================================

app.use((req, res) => {

    res.status(404).json({

        success: false,

        message:
            "API route not found."

    });

});


// ================================
// ERROR HANDLER
// ================================

app.use((err, req, res, next) => {

    console.error(
        "Server error:",
        err
    );

    res.status(500).json({

        success: false,

        message:
            "Internal server error."

    });

});


// ================================
// START SERVER
// ================================

app.listen(PORT, () => {

    console.log(
        `🚀 New Brand Fashion Backend running on port ${PORT}`
    );

});