const jwt = require("jsonwebtoken");

function authenticateToken(req, res, next) {
    const authHeader = req.headers["authorization"];

    const token = authHeader && authHeader.split(" ")[1];

    if (!token) {
        return res.status(401).json({
            success: false,
            message: "Access denied. Login required."
        });
    }

    jwt.verify(
        token,
        process.env.JWT_SECRET || "new-brand-fashion-secret",
        (err, user) => {
            if (err) {
                return res.status(403).json({
                    success: false,
                    message: "Invalid or expired token."
                });
            }

            req.user = user;

            next();
        }
    );
}

module.exports = authenticateToken;