const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../config/database");

const router = express.Router();


// =====================================================
// REGISTER
// =====================================================

router.post("/register", async (req, res) => {
    try {
        const {
            name,
            email,
            phone,
            password,
            address
        } = req.body;

        if (!name || !email || !password) {
            return res.status(400).json({
                success: false,
                message: "Name, email and password are required."
            });
        }

        const cleanEmail = email.trim().toLowerCase();

        db.get(
            "SELECT id FROM users WHERE email = ?",
            [cleanEmail],
            async (err, user) => {

                if (err) {
                    console.error("Register check error:", err);

                    return res.status(500).json({
                        success: false,
                        message: "Database error."
                    });
                }

                if (user) {
                    return res.status(409).json({
                        success: false,
                        message: "An account with this email already exists."
                    });
                }

                const hashedPassword = await bcrypt.hash(
                    password,
                    10
                );

                db.run(
                    `
                    INSERT INTO users
                    (name, email, phone, password, address, role)
                    VALUES (?, ?, ?, ?, ?, ?)
                    `,
                    [
                        name.trim(),
                        cleanEmail,
                        phone || "",
                        hashedPassword,
                        address || "",
                        "customer"
                    ],
                    function (err) {

                        if (err) {
                            console.error(
                                "Register error:",
                                err
                            );

                            return res.status(500).json({
                                success: false,
                                message: "Registration failed."
                            });
                        }

                        return res.status(201).json({
                            success: true,
                            message: "Account created successfully.",
                            user: {
                                id: this.lastID,
                                name: name.trim(),
                                email: cleanEmail,
                                phone: phone || "",
                                role: "customer"
                            }
                        });
                    }
                );
            }
        );

    } catch (error) {

        console.error(
            "Register server error:",
            error
        );

        res.status(500).json({
            success: false,
            message: "Server error."
        });
    }
});


// =====================================================
// LOGIN
// =====================================================

router.post("/login", (req, res) => {

    const {
        email,
        password
    } = req.body;

    if (!email || !password) {
        return res.status(400).json({
            success: false,
            message: "Email and password are required."
        });
    }

    const cleanEmail =
        email.trim().toLowerCase();

    db.get(
        "SELECT * FROM users WHERE email = ?",
        [cleanEmail],
        async (err, user) => {

            if (err) {
                console.error(
                    "Login database error:",
                    err
                );

                return res.status(500).json({
                    success: false,
                    message: "Database error."
                });
            }

            if (!user) {
                return res.status(401).json({
                    success: false,
                    message: "Invalid email or password."
                });
            }

            const passwordMatch =
                await bcrypt.compare(
                    password,
                    user.password
                );

            if (!passwordMatch) {
                return res.status(401).json({
                    success: false,
                    message: "Invalid email or password."
                });
            }


            // ==========================================
            // USER ROLE
            // ==========================================

            const userRole =
                user.role || "customer";


            // ==========================================
            // JWT TOKEN
            // ==========================================

            const token =
                jwt.sign(
                    {
                        id: user.id,
                        email: user.email,
                        role: userRole
                    },
                    process.env.JWT_SECRET ||
                    "new-brand-fashion-secret",
                    {
                        expiresIn: "7d"
                    }
                );


            // ==========================================
            // RESPONSE
            // ==========================================

            return res.json({

                success: true,

                message:
                    "Login successful.",

                token: token,

                user: {

                    id:
                        user.id,

                    name:
                        user.name,

                    email:
                        user.email,

                    phone:
                        user.phone || "",

                    address:
                        user.address || "",

                    role:
                        userRole

                }

            });
        }
    );
});


// =====================================================
// CHANGE PASSWORD
// =====================================================

router.post("/change-password", (req, res) => {

    const {
        userId,
        currentPassword,
        newPassword
    } = req.body;


    if (
        !userId ||
        !currentPassword ||
        !newPassword
    ) {

        return res.status(400).json({

            success: false,

            message:
                "User ID, current password and new password are required."

        });
    }


    if (newPassword.length < 6) {

        return res.status(400).json({

            success: false,

            message:
                "New password must be at least 6 characters."

        });
    }


    db.get(
        "SELECT * FROM users WHERE id = ?",
        [userId],
        async (err, user) => {

            if (err) {

                console.error(
                    "Change password database error:",
                    err
                );

                return res.status(500).json({

                    success: false,

                    message:
                        "Database error."

                });
            }


            if (!user) {

                return res.status(404).json({

                    success: false,

                    message:
                        "User account not found."

                });
            }


            try {

                const passwordMatch =
                    await bcrypt.compare(
                        currentPassword,
                        user.password
                    );


                if (!passwordMatch) {

                    return res.status(401).json({

                        success: false,

                        message:
                            "Current password is incorrect."

                    });
                }


                const samePassword =
                    await bcrypt.compare(
                        newPassword,
                        user.password
                    );


                if (samePassword) {

                    return res.status(400).json({

                        success: false,

                        message:
                            "New password must be different from current password."

                    });
                }


                const hashedPassword =
                    await bcrypt.hash(
                        newPassword,
                        10
                    );


                db.run(
                    `
                    UPDATE users
                    SET password = ?
                    WHERE id = ?
                    `,
                    [
                        hashedPassword,
                        userId
                    ],
                    function (updateErr) {

                        if (updateErr) {

                            console.error(
                                "Password update error:",
                                updateErr
                            );

                            return res.status(500).json({

                                success: false,

                                message:
                                    "Password could not be changed."

                            });
                        }


                        if (this.changes === 0) {

                            return res.status(404).json({

                                success: false,

                                message:
                                    "User account not found."

                            });
                        }


                        return res.json({

                            success: true,

                            message:
                                "Password changed successfully."

                        });

                    }
                );

            } catch (passwordError) {

                console.error(
                    "Password processing error:",
                    passwordError
                );

                return res.status(500).json({

                    success: false,

                    message:
                        "Password processing failed."

                });

            }

        }
    );

});


module.exports = router;