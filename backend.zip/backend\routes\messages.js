const express = require("express");
const router = express.Router();

const db = require("../config/database");


// ======================================================
// GET ALL MESSAGES
// ======================================================

router.get("/", (req, res) => {

    const sql = `
        SELECT *
        FROM messages
        ORDER BY created_at DESC
    `;

    db.all(sql, [], (err, rows) => {

        if (err) {

            console.error(
                "❌ Get messages error:",
                err.message
            );

            return res.status(500).json({
                success: false,
                message: "Messages load nahi ho sake."
            });
        }

        res.json({
            success: true,
            messages: rows
        });

    });

});


// ======================================================
// GET SINGLE CONVERSATION
// ======================================================

router.get("/conversation/:conversationId", (req, res) => {

    const { conversationId } = req.params;

    const sql = `
        SELECT *
        FROM messages
        WHERE conversation_id = ?
        ORDER BY created_at ASC
    `;

    db.all(sql, [conversationId], (err, rows) => {

        if (err) {

            console.error(
                "❌ Conversation load error:",
                err.message
            );

            return res.status(500).json({
                success: false,
                message: "Conversation load nahi ho saki."
            });
        }

        res.json({
            success: true,
            messages: rows
        });

    });

});


// ======================================================
// SEND MESSAGE
// ======================================================

router.post("/", (req, res) => {

    const {
        customer_name,
        customer_email,
        customer_phone,
        subject,
        message,
        sender_type,
        conversation_id
    } = req.body;


    if (!customer_name || !message) {

        return res.status(400).json({
            success: false,
            message: "Customer name aur message required hain."
        });

    }


    const finalSenderType =
        sender_type || "customer";


    const finalStatus =
        finalSenderType === "admin"
            ? "read"
            : "unread";


    const finalConversationId =
        conversation_id ||
        `CONV-${Date.now()}`;


    const sql = `
        INSERT INTO messages (
            customer_name,
            customer_email,
            customer_phone,
            subject,
            message,
            sender_type,
            status,
            conversation_id
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;


    const values = [

        customer_name,

        customer_email || "",

        customer_phone || "",

        subject || "",

        message,

        finalSenderType,

        finalStatus,

        finalConversationId

    ];


    db.run(sql, values, function (err) {

        if (err) {

            console.error(
                "❌ Send message error:",
                err.message
            );

            return res.status(500).json({
                success: false,
                message: "Message save nahi ho saka."
            });

        }


        res.status(201).json({

            success: true,

            message:
                "Message successfully send ho gaya.",

            messageId: this.lastID,

            conversationId:
                finalConversationId

        });

    });

});


// ======================================================
// MARK MESSAGE AS READ
// ======================================================

router.put("/:id/read", (req, res) => {

    const { id } = req.params;


    const sql = `
        UPDATE messages
        SET status = 'read'
        WHERE id = ?
    `;


    db.run(sql, [id], function (err) {

        if (err) {

            console.error(
                "❌ Mark read error:",
                err.message
            );

            return res.status(500).json({
                success: false,
                message: "Message read nahi ho saka."
            });

        }


        res.json({

            success: true,

            message:
                "Message marked as read."

        });

    });

});


// ======================================================
// DELETE CONVERSATION
// ======================================================

router.delete(
    "/conversation/:conversationId",
    (req, res) => {

        const { conversationId } = req.params;


        const sql = `
            DELETE FROM messages
            WHERE conversation_id = ?
        `;


        db.run(
            sql,
            [conversationId],
            function (err) {

                if (err) {

                    console.error(
                        "❌ Delete conversation error:",
                        err.message
                    );

                    return res.status(500).json({
                        success: false,
                        message:
                            "Conversation delete nahi ho saki."
                    });

                }


                res.json({

                    success: true,

                    message:
                        "Conversation successfully delete ho gayi."

                });

            }
        );

    }
);


// ======================================================
// MESSAGE STATS
// ======================================================

router.get("/stats/summary", (req, res) => {

    const sql = `
        SELECT

            COUNT(*) AS total,

            SUM(
                CASE
                    WHEN status = 'unread'
                    AND sender_type = 'customer'
                    THEN 1
                    ELSE 0
                END
            ) AS unread,

            SUM(
                CASE
                    WHEN sender_type = 'admin'
                    THEN 1
                    ELSE 0
                END
            ) AS replied

        FROM messages
    `;


    db.get(sql, [], (err, row) => {

        if (err) {

            console.error(
                "❌ Message stats error:",
                err.message
            );

            return res.status(500).json({
                success: false,
                message:
                    "Message stats load nahi ho sake."
            });

        }


        res.json({

            success: true,

            stats: {

                total: row.total || 0,

                unread: row.unread || 0,

                replied: row.replied || 0

            }

        });

    });

});


module.exports = router;