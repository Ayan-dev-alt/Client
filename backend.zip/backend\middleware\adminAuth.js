const jwt = require("jsonwebtoken");

function adminAuth(req, res, next) {
    const authHeader = req.headers["authorization"];

    const token = authHeader && authHeader.split(" ")[1];

    if (!token) {
        return res.status(401).json({
            success: false,
            message: "Admin login required."
        });
    }

    jwt.verify(
        token,
        process.env.JWT_SECRET || "new-brand-fashion-secret",
        (err, user) => {
            if (err) {
                return res.status(403).json({
                    success: false,
                    message: "Invalid or expired admin token."
                });
            }

            if (user.role !== "admin") {
                return res.status(403).json({
                    success: false,
                    message: "Admin access only."
                });
            }

            req.user = user;

            next();
        }
    );
}

module.exports = adminAuth;