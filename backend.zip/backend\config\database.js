const sqlite3 = require("sqlite3").verbose();
const path = require("path");

const dbPath = path.join(__dirname, "..", "database.db");

const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error(
            "❌ Database connection failed:",
            err.message
        );
    } else {
        console.log("✅ SQLite database connected");

        // ================================
        // USERS TABLE
        // ================================

        db.run(`
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                phone TEXT,
                password TEXT NOT NULL,
                address TEXT,
                role TEXT DEFAULT 'customer',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `, (err) => {
            if (err) {
                console.error(
                    "❌ Users table creation failed:",
                    err.message
                );
            } else {
                console.log("✅ Users table ready");

                // Add role column to old database
                db.all(
                    `PRAGMA table_info(users)`,
                    [],
                    (err, columns) => {
                        if (err) {
                            console.error(
                                "❌ Users table check failed:",
                                err.message
                            );
                            return;
                        }

                        const roleColumnExists = columns.some(
                            column => column.name === "role"
                        );

                        if (!roleColumnExists) {
                            db.run(
                                `ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'customer'`,
                                (err) => {
                                    if (err) {
                                        console.error(
                                            "❌ Role column could not be added:",
                                            err.message
                                        );
                                    } else {
                                        console.log(
                                            "✅ Users role column added"
                                        );
                                    }
                                }
                            );
                        } else {
                            console.log(
                                "✅ Users role column already exists"
                            );
                        }
                    }
                );
            }
        });

        // ================================
        // PRODUCTS TABLE
        // ================================

        db.run(`
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                category TEXT NOT NULL,
                price REAL NOT NULL,
                description TEXT,
                image TEXT,
                images TEXT,
                stock INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `, (err) => {
            if (err) {
                console.error(
                    "❌ Products table creation failed:",
                    err.message
                );
            } else {
                console.log("✅ Products table ready");

                db.all(
                    `PRAGMA table_info(products)`,
                    [],
                    (err, columns) => {
                        if (err) {
                            console.error(
                                "❌ Products table check failed:",
                                err.message
                            );
                            return;
                        }

                        const imagesColumnExists = columns.some(
                            column => column.name === "images"
                        );

                        if (!imagesColumnExists) {
                            db.run(
                                `ALTER TABLE products ADD COLUMN images TEXT`,
                                (err) => {
                                    if (err) {
                                        console.error(
                                            "❌ Images column could not be added:",
                                            err.message
                                        );
                                    } else {
                                        console.log(
                                            "✅ Products images column added"
                                        );
                                    }
                                }
                            );
                        } else {
                            console.log(
                                "✅ Products images column already exists"
                            );
                        }
                    }
                );
            }
        });

        // ================================
        // ORDERS TABLE
        // ================================

        db.run(`
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_number TEXT NOT NULL UNIQUE,
                customer TEXT NOT NULL,
                note TEXT,
                payment TEXT,
                payment_method TEXT,
                transaction_id TEXT,
                payment_screenshot TEXT,
                payment_proof_name TEXT,
                items TEXT NOT NULL,
                subtotal REAL DEFAULT 0,
                shipping REAL DEFAULT 0,
                total REAL DEFAULT 0,
                advance_payment REAL DEFAULT 0,
                status TEXT DEFAULT 'Pending',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `, (err) => {
            if (err) {
                console.error(
                    "❌ Orders table creation failed:",
                    err.message
                );
            } else {
                console.log("✅ Orders table ready");
            }
        });

        // ================================
        // MESSAGES TABLE
        // ================================

        db.run(`
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_name TEXT NOT NULL,
                customer_email TEXT DEFAULT '',
                customer_phone TEXT DEFAULT '',
                subject TEXT DEFAULT '',
                message TEXT NOT NULL,
                sender_type TEXT DEFAULT 'customer',
                status TEXT DEFAULT 'unread',
                conversation_id TEXT DEFAULT '',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `, (err) => {
            if (err) {
                console.error(
                    "❌ Messages table creation failed:",
                    err.message
                );
            } else {
                console.log("✅ Messages table ready");
            }
        });

        // ================================
        // SETTINGS TABLE
        // ================================

        db.run(`
            CREATE TABLE IF NOT EXISTS settings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                store_name TEXT DEFAULT 'New Brand Fashion',
                store_email TEXT DEFAULT '',
                store_phone TEXT DEFAULT '',
                currency TEXT DEFAULT 'PKR',
                store_address TEXT DEFAULT '',
                shipping_charge REAL DEFAULT 200,
                free_shipping_above REAL DEFAULT 0,
                store_status INTEGER DEFAULT 1,
                cod_enabled INTEGER DEFAULT 1,
                registration_enabled INTEGER DEFAULT 1,
                admin_name TEXT DEFAULT '',
                admin_email TEXT DEFAULT '',
                admin_phone TEXT DEFAULT '',
                admin_photo TEXT DEFAULT '',
                notify_orders INTEGER DEFAULT 1,
                notify_customers INTEGER DEFAULT 1,
                notify_messages INTEGER DEFAULT 1,
                notify_low_stock INTEGER DEFAULT 1,
                notify_email INTEGER DEFAULT 1,
                two_factor INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `, (err) => {
            if (err) {
                console.error(
                    "❌ Settings table creation failed:",
                    err.message
                );
            } else {
                console.log("✅ Settings table ready");

                // Create default settings
                db.get(
                    `SELECT id FROM settings LIMIT 1`,
                    [],
                    (err, row) => {
                        if (err) {
                            console.error(
                                "❌ Settings check failed:",
                                err.message
                            );
                            return;
                        }

                        if (!row) {
                            db.run(`
                                INSERT INTO settings (
                                    store_name,
                                    store_email,
                                    store_phone,
                                    currency,
                                    store_address,
                                    shipping_charge,
                                    free_shipping_above,
                                    store_status,
                                    cod_enabled,
                                    registration_enabled,
                                    admin_name,
                                    admin_email,
                                    admin_phone,
                                    notify_orders,
                                    notify_customers,
                                    notify_messages,
                                    notify_low_stock,
                                    notify_email,
                                    two_factor
                                )
                                VALUES (
                                    'New Brand Fashion',
                                    '',
                                    '',
                                    'PKR',
                                    '',
                                    200,
                                    0,
                                    1,
                                    1,
                                    1,
                                    '',
                                    '',
                                    '',
                                    1,
                                    1,
                                    1,
                                    1,
                                    1,
                                    0
                                )
                            `, (err) => {
                                if (err) {
                                    console.error(
                                        "❌ Default settings creation failed:",
                                        err.message
                                    );
                                } else {
                                    console.log(
                                        "✅ Default settings created"
                                    );
                                }
                            });
                        } else {
                            console.log(
                                "✅ Default settings already exist"
                            );
                        }
                    }
                );
            }
        });
    }
});

module.exports = db;