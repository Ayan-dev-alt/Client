const express = require("express");
const db = require("../config/database");
const adminAuth = require("../middleware/adminAuth");

const router = express.Router();


/*
========================================
HELPER FUNCTION
FORMAT PRODUCT IMAGES
========================================
*/

function formatProduct(product) {

    let images = [];

    try {

        if (product.images) {

            const parsedImages =
                JSON.parse(product.images);

            if (Array.isArray(parsedImages)) {
                images = parsedImages;
            }

        }

    } catch (error) {

        console.error(
            "Product images parse error:",
            error.message
        );

    }


    // Old products fallback
    if (
        images.length === 0 &&
        product.image
    ) {

        images = [
            product.image
        ];

    }


    return {
        ...product,
        images: images
    };

}


/*
========================================
GET ALL PRODUCTS
PUBLIC ROUTE
GET /api/products
========================================
*/

router.get("/", (req, res) => {

    db.all(
        "SELECT * FROM products ORDER BY id DESC",
        [],
        (err, products) => {

            if (err) {

                console.error(
                    "Get products error:",
                    err
                );

                return res.status(500).json({
                    success: false,
                    message: "Database error."
                });

            }


            const formattedProducts =
                products.map(
                    formatProduct
                );


            res.json({

                success: true,

                products:
                    formattedProducts

            });

        }
    );

});


/*
========================================
GET SINGLE PRODUCT
PUBLIC ROUTE
GET /api/products/:id
========================================
*/

router.get("/:id", (req, res) => {

    const productId =
        req.params.id;


    db.all(
        "SELECT * FROM products WHERE id = ?",
        [productId],
        (err, products) => {

            if (err) {

                console.error(
                    "Get product error:",
                    err
                );

                return res.status(500).json({
                    success: false,
                    message: "Database error."
                });

            }


            if (
                !products ||
                products.length === 0
            ) {

                return res.status(404).json({
                    success: false,
                    message: "Product not found."
                });

            }


            const product =
                products[0];


            const formattedProduct =
                formatProduct(product);


            res.json({

                success: true,

                product:
                    formattedProduct

            });

        }
    );

});


/*
========================================
ADD PRODUCT
ADMIN ONLY
POST /api/products
========================================
*/

router.post("/", adminAuth, (req, res) => {

    const {
        name,
        category,
        price,
        description,
        image,
        images,
        stock
    } = req.body;


    /*
    ----------------------------------------
    REQUIRED FIELDS
    ----------------------------------------
    */

    if (
        !name ||
        !category ||
        price === undefined ||
        price === null
    ) {

        return res.status(400).json({

            success: false,

            message:
                "Name, category and price are required."

        });

    }


    /*
    ----------------------------------------
    BASIC DATA
    ----------------------------------------
    */

    const productName =
        name.trim();

    const productCategory =
        category.trim();

    const productPrice =
        Number(price);

    const productDescription =
        description || "";


    /*
    ----------------------------------------
    IMAGES
    ----------------------------------------
    */

    let productImages = [];


    if (Array.isArray(images)) {

        productImages =
            images
                .filter(
                    img =>
                        typeof img === "string" &&
                        img.trim() !== ""
                )
                .slice(0, 4);

    }


    /*
    If images array is not provided,
    use old image field.
    */

    if (
        productImages.length === 0 &&
        image
    ) {

        productImages = [
            image
        ];

    }


    /*
    First image becomes main image.
    */

    const productImage =
        productImages[0] || "";


    /*
    Save images as JSON.
    */

    const productImagesJSON =
        JSON.stringify(
            productImages
        );


    /*
    ----------------------------------------
    STOCK
    ----------------------------------------
    */

    const productStock =
        stock === undefined ||
        stock === null ||
        stock === ""
            ? 0
            : Number(stock);


    /*
    ----------------------------------------
    PRICE VALIDATION
    ----------------------------------------
    */

    if (
        !Number.isFinite(productPrice) ||
        productPrice < 0
    ) {

        return res.status(400).json({

            success: false,

            message:
                "Invalid product price."

        });

    }


    /*
    ----------------------------------------
    STOCK VALIDATION
    ----------------------------------------
    */

    if (
        !Number.isFinite(productStock) ||
        productStock < 0
    ) {

        return res.status(400).json({

            success: false,

            message:
                "Invalid stock quantity."

        });

    }


    /*
    ----------------------------------------
    ADD TO DATABASE
    ----------------------------------------
    */

    db.run(

        `
        INSERT INTO products
        (
            name,
            category,
            price,
            description,
            image,
            images,
            stock
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
        `,

        [
            productName,
            productCategory,
            productPrice,
            productDescription,
            productImage,
            productImagesJSON,
            productStock
        ],

        function (err) {

            if (err) {

                console.error(
                    "Add product error:",
                    err
                );

                return res.status(500).json({

                    success: false,

                    message:
                        "Product could not be added."

                });

            }


            /*
            --------------------------------
            RESPONSE
            --------------------------------
            */

            res.status(201).json({

                success: true,

                message:
                    "Product added successfully.",

                product: {

                    id:
                        this.lastID,

                    name:
                        productName,

                    category:
                        productCategory,

                    price:
                        productPrice,

                    description:
                        productDescription,

                    image:
                        productImage,

                    images:
                        productImages,

                    stock:
                        productStock

                }

            });

        }

    );

});


/*
========================================
UPDATE PRODUCT
ADMIN ONLY
PUT /api/products/:id
========================================
*/

router.put("/:id", adminAuth, (req, res) => {

    const productId =
        req.params.id;


    const {
        name,
        category,
        price,
        description,
        image,
        images,
        stock
    } = req.body;


    /*
    ----------------------------------------
    REQUIRED FIELDS
    ----------------------------------------
    */

    if (
        !name ||
        !category ||
        price === undefined ||
        price === null
    ) {

        return res.status(400).json({

            success: false,

            message:
                "Name, category and price are required."

        });

    }


    /*
    ----------------------------------------
    PRICE
    ----------------------------------------
    */

    const productPrice =
        Number(price);


    /*
    ----------------------------------------
    STOCK
    ----------------------------------------
    */

    const productStock =
        stock === undefined ||
        stock === null ||
        stock === ""
            ? 0
            : Number(stock);


    /*
    ----------------------------------------
    VALIDATE PRICE
    ----------------------------------------
    */

    if (
        !Number.isFinite(productPrice) ||
        productPrice < 0
    ) {

        return res.status(400).json({

            success: false,

            message:
                "Invalid product price."

        });

    }


    /*
    ----------------------------------------
    VALIDATE STOCK
    ----------------------------------------
    */

    if (
        !Number.isFinite(productStock) ||
        productStock < 0
    ) {

        return res.status(400).json({

            success: false,

            message:
                "Invalid stock quantity."

        });

    }


    /*
    ----------------------------------------
    PREPARE IMAGES
    ----------------------------------------
    */

    let productImages = [];


    if (Array.isArray(images)) {

        productImages =
            images
                .filter(
                    img =>
                        typeof img === "string" &&
                        img.trim() !== ""
                )
                .slice(0, 4);

    }


    /*
    If new images are not provided,
    use old image field.
    */

    if (
        productImages.length === 0 &&
        image
    ) {

        productImages = [
            image
        ];

    }


    /*
    First image becomes main image.
    */

    const productImage =
        productImages[0] || "";


    /*
    Save images as JSON.
    */

    const productImagesJSON =
        JSON.stringify(
            productImages
        );


    /*
    ----------------------------------------
    UPDATE DATABASE
    ----------------------------------------
    */

    db.run(

        `
        UPDATE products

        SET
            name = ?,
            category = ?,
            price = ?,
            description = ?,
            image = ?,
            images = ?,
            stock = ?

        WHERE id = ?
        `,

        [
            name.trim(),
            category.trim(),
            productPrice,
            description || "",
            productImage,
            productImagesJSON,
            productStock,
            productId
        ],

        function (err) {

            if (err) {

                console.error(
                    "Update product error:",
                    err
                );

                return res.status(500).json({

                    success: false,

                    message:
                        "Product could not be updated."

                });

            }


            /*
            --------------------------------
            PRODUCT NOT FOUND
            --------------------------------
            */

            if (this.changes === 0) {

                return res.status(404).json({

                    success: false,

                    message:
                        "Product not found."

                });

            }


            /*
            --------------------------------
            SUCCESS
            --------------------------------
            */

            res.json({

                success: true,

                message:
                    "Product updated successfully.",

                product: {

                    id:
                        Number(productId),

                    name:
                        name.trim(),

                    category:
                        category.trim(),

                    price:
                        productPrice,

                    description:
                        description || "",

                    image:
                        productImage,

                    images:
                        productImages,

                    stock:
                        productStock

                }

            });

        }

    );

});


/*
========================================
DELETE PRODUCT
ADMIN ONLY
DELETE /api/products/:id
========================================
*/

router.delete("/:id", adminAuth, (req, res) => {

    const productId =
        req.params.id;


    db.run(

        "DELETE FROM products WHERE id = ?",

        [productId],

        function (err) {

            if (err) {

                console.error(
                    "Delete product error:",
                    err
                );

                return res.status(500).json({

                    success: false,

                    message:
                        "Product could not be deleted."

                });

            }


            if (this.changes === 0) {

                return res.status(404).json({

                    success: false,

                    message:
                        "Product not found."

                });

            }


            res.json({

                success: true,

                message:
                    "Product deleted successfully."

            });

        }

    );

});


/*
========================================
EXPORT ROUTER
========================================
*/

module.exports = router;